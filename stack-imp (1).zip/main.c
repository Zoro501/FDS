#include <stdio.h>

#define MAX 8 // Define the maximum size of the stack

int main() {
    int stack[MAX], top = -1, choice, lastInserted = -1;

    do {
        printf("\nChoose an Operation to Perform on Stack:\n");
        printf("1) Push\n2) Pop\n3) Display\n4) Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                if (top >= MAX - 1) { // Check for stack overflow
                    printf("Stack overflow!\n");
                } else {
                    printf("Enter element to push: ");
                    top++;
                    scanf("%d", &stack[top]);
                    lastInserted = stack[top]; // Update the last inserted element
                    printf("Element %d pushed onto the stack at index %d.\n", stack[top], top);
                }
                break;

            case 2:
                if (top < 0) { // Check for stack underflow
                    printf("Stack underflow!\n");
                } else {
                    printf("Element popped: %d from stack %d.\n", stack[top], top);
                    top--;
                }
                break;

            case 3:
                if (top < 0) { // Check if the stack is empty
                    printf("Stack is empty.\n");
                } else {
                    printf("Stack contents:\n");
                    for (int i = top; i >= 0; i--) {
                        printf("Stack %d: %d\n", i, stack[i]);
                    }
                    printf("Last inserted element: %d\n", lastInserted);
                }
                break;

            case 4:
                printf("Exiting program.\n");
                break;

            default:
                printf("Invalid choice. Please enter a valid option.\n");
        }
    } while (choice != 4);

    return 0;
}